﻿DateTime data;
Console.WriteLine("Digite uma data: ");
data = DateTime.Parse(Console.ReadLine());
Console.WriteLine(data);
Console.WriteLine(data.ToString("dd"));
