// Primeira maneira usando WHILE: (não estava. no exercicio, mas foi o primeiro que eu imaginei, depois eu li direito e fiz o segundo)

int num = 101, i = 0;
while (i < 100)
{
    num --;
    Console.WriteLine(num);
    i++;
}




// 2 maneira usando o FOR:

for (int a = 100; a > 0; a--)
{
    Console.WriteLine(a);
}

