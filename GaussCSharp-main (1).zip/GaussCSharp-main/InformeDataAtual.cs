﻿using System;
 namespace informeDiaAtual;

class program
{
    static void Main (string[] args)
    {

        Console.WriteLine(DateTime.Now.ToString("dd/MM/yyyy"));
    }
}

