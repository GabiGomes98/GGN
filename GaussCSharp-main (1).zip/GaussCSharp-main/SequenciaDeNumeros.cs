﻿using System;


List<int> valores = new List<int>();

int i = 0;

while (i < 10)
{
    valores.Add(i);
    i += 1;

    Console.WriteLine(i);
}