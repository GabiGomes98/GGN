﻿using System;
namespace carro
{
	public class Carro
	{
		public string modelo;
		public int ano;
		public float km;
		
	}

	public class Motor
	{
		public string modelo;
		public string tipo;
		public int tamanho;
	}
}

