float media, fracao1, fracao2, fracao3, somaFracao;   
float n = 3f,num1 = 4f,num2 = 5f, num3 = 8f;

  fracao1 = (1/num1);
  fracao2 = (1/num2);
  fracao3 = (1/num3);

  somaFracao = fracao1 +fracao2 + fracao3;
  media = n / somaFracao;
  Console.WriteLine("a média harmonica é : " + media);
